package com.guiliano.supportsushi

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var english = false
    private lateinit var page: LinearLayout
    private val green = Color.rgb(18, 62, 49)
    private val gold = Color.rgb(205, 166, 80)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String) {
        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(247, 247, 242))
        }
        scroll.addView(page)
        setContentView(scroll)
        val head = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(gold)
            setPadding(0, 8, 0, 20)
            gravity = Gravity.CENTER
        }
        page.addView(head)
    }

    private fun button(label: String, action: () -> Unit) {
        page.addView(Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            textSize = 16f
            setOnClickListener { action() }
        })
    }

    private fun line(text: String, size: Float = 17f) {
        page.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(40, 48, 43))
            setPadding(4, 10, 4, 10)
        })
    }

    private fun showHome() {
        base("GUILIANO SUPPORT SUSHI")
        button(if (english) "Français" else "English") { english = !english; showHome() }
        line(if (english) "Professional sushi tools • Global edition" else "Outils professionnels pour sushi • Édition mondiale", 18f)
        button(if (english) "Sushi rice calculator" else "Calculateur de riz à sushi") { showRice() }
        button(if (english) "Food cost & margin" else "Coût matière et marge") { showCost() }
        button(if (english) "Sushi recipe library" else "Bibliothèque de recettes sushi") { showRecipes() }
        button(if (english) "Premium" else "Premium") { showPremium() }
        line("Version 2.0  •  Français / English", 13f)
    }

    private fun showRice() {
        base(if (english) "Sushi rice calculator" else "Calculateur de riz à sushi")
        val rice = field("Rice (g)", "200")
        val water = field("Water (g)", "250")
        val vinegar = field("Vinegar (g)", "20")
        val sugar = field("Sugar (g)", "10")
        val salt = field("Salt (g)", "4")
        val result = TextView(this).apply { textSize = 17f; setTextColor(green); setPadding(0,18,0,18) }
        button(if (english) "Calculate" else "Calculer") {
            val r = rice.text.toString().toDoubleOrNull() ?: 0.0
            fun pct(v: EditText) = (v.text.toString().toDoubleOrNull() ?: 0.0) / (if (r == 0.0) 1.0 else r) * 100
            result.text = "Water: %.1f%%\nVinegar: %.1f%%\nSugar: %.1f%%\nSalt: %.1f%%".format(pct(water), pct(vinegar), pct(sugar), pct(salt))
        }
        page.addView(result)
        button(if (english) "Back" else "Retour") { showHome() }
    }

    private fun field(label: String, value: String): EditText {
        line(label)
        val e = EditText(this).apply { setText(value); inputType = 8194 }
        page.addView(e)
        return e
    }

    private fun showCost() {
        base(if (english) "Food cost & margin" else "Coût matière et marge")
        val cost = field("Ingredient cost", "5")
        val price = field("Selling price", "15")
        val result = TextView(this).apply { textSize = 18f; setTextColor(green) }
        button(if (english) "Calculate" else "Calculer") {
            val c = cost.text.toString().toDoubleOrNull() ?: 0.0
            val p = price.text.toString().toDoubleOrNull() ?: 0.0
            val margin = if (p > 0) (p-c)/p*100 else 0.0
            result.text = "Food cost: %.2f%%\nGross margin: %.2f%%".format(if(p>0)c/p*100 else 0.0, margin)
        }
        page.addView(result)
        button("Back / Retour") { showHome() }
    }

    private fun showRecipes() {
        base(if (english) "Sushi recipes" else "Recettes sushi")
        line("Maki • Nigiri • Uramaki • Temaki • Hosomaki • Futomaki • Chirashi")
        line(if (english) "Recipe cards and academy content will be expanded in future releases." else "Les fiches recettes et le contenu de l'académie seront enrichis dans les prochaines versions.")
        button("Back / Retour") { showHome() }
    }

    private fun showPremium() {
        base("GUILIANO PREMIUM")
        line(if (english) "Premium subscription preview. Payment is not yet connected." else "Aperçu de l'abonnement Premium. Le paiement n'est pas encore connecté.")
        line("19.99 AED / month • 199 AED / year")
        button("Back / Retour") { showHome() }
    }
}
